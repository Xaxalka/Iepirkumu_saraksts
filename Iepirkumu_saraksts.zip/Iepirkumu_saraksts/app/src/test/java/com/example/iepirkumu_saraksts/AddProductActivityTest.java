package com.example.iepirkumu_saraksts;

import junit.framework.TestCase;

public class AddProductActivityTest extends TestCase {

}